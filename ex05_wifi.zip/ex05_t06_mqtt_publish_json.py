import time
import network
from machine import Pin
from umqtt import MQTTClient
import gc
import random
import json

gc.collect()

ssid = "ASUS"
password = "Doktorzec1"

data = {
    "device" : "Rpi Pico W",
    "dev_value" : 10
    }

# Connect to WiFi
wlan = network.WLAN(network.STA_IF)
wlan.active(True)
wlan.connect(ssid, password)
print(f'Connecting to the {ssid} network')
while wlan.isconnected() == False:
    print('Waiting for connection...')
    time.sleep(0.5)
print(f'Connected to the {ssid} network')
print(f'IP adres is {wlan.ifconfig()[0]}')

mqtt_server = "192.168.1.234"
mqtt_username = ""  # username
mqtt_password = ""  # user password
mqtt_publish_topic = "mqtt_json"  
mqtt_client_id = "rpi_pico_w"

mqtt_client = MQTTClient(
        client_id=mqtt_client_id,
        server=mqtt_server,
#        user=mqtt_username,
#        password=mqtt_password
        )

mqtt_client.connect()

try:
    message_cnt = 0
    while message_cnt < 20:
        data['dev_value'] = random.randint(0, 100) 
        json_str = json.dumps(data)
        print(f'Publish {json_str}')
        mqtt_client.publish(mqtt_publish_topic, json_str)
        message_cnt += 1
        time.sleep(2)
except Exception as e:
    print(f'Failed to publish message: {e}')
finally:
    mqtt_client.disconnect()
    print("MQTT client disconnected")
    wlan.disconnect()