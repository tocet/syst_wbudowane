import network
import time
from umqtt import MQTTClient
import gc

gc.collect()

ssid = "ASUS"
password = "Doktorzec1"

# Connect to WiFi
wlan = network.WLAN(network.STA_IF)
wlan.active(True)
wlan.connect(ssid, password)
print(f'Connecting to the {ssid} network')
while wlan.isconnected() == False:
    print('Waiting for connection...')
    time.sleep(0.5)
print(f'Connected to the {ssid} network')
print(f'IP adres is {wlan.ifconfig()[0]}')

# Print out of what was received over MQTT
def mqtt_subscription_callback(topic, message):
    print(f'Topic {topic}')
    print(f'Received message {message}')  

mqtt_server = "192.168.1.234"    
mqtt_publish_topic = "number"
mqtt_client_id = "rpi_pico_w"
mqtt_client = MQTTClient(
        client_id=mqtt_client_id,
        server=mqtt_server)
mqtt_client.set_callback(mqtt_subscription_callback)
mqtt_client.connect()

# Subscribe to the MQTT topic
mqtt_topic = 'mqtt_num'
mqtt_client.subscribe(mqtt_topic)
print(f'Connected and subscribed to the {mqtt_topic}')

try:
    while True:
        print(f'Waiting for messages on {mqtt_topic}')
        mqtt_client.wait_msg()
except Exception as e:
    print(f'Failed to wait for MQTT messages: {e}')
finally:
    mqtt_client.disconnect()