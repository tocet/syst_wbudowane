import machine
import utime as t

led_builtin = machine.Pin(25,machine.Pin.OUT)
i = 0

while True:
    led_builtin.toggle()
    t.sleep(0.5)
    i+=1
    print(f'Current interation is {i}')
        

            
